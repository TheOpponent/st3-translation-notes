#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# ZetpeR xax007@yandex.ru
# Вынемание текста из распакованных скриптов .SBX.bin игры Sakura Taisen 3 PC
# В файле S1106.SBX строчка текста 81 40 90 EC FA B1 83 71 83 8D 83 86 83 4C не распаковывается кодировкой shift_jis остальные распаковываются 
# При использование кодировки shift_jis_2004 различия только в файлах S1003.SBX и S1106.SBX

import os, sys
import struct
import time
import io
import datetime

path = os.path.realpath(os.path.dirname(sys.argv[0]))

class Profiler(object):
    def __enter__(self):
        self._startTime = time.time()
    def __exit__(self, type, value, traceback):
        dd = time.time() - self._startTime
        seconds_f, mikro = str(dd).split(".")
        print("Часы минуты секунды",str(datetime.timedelta(seconds=int(seconds_f))),"", "{:.3f} sec".format(time.time() - self._startTime))

def main():
    if os.path.exists(path+"\\Unpack") == False:
        os.makedirs(path+"\\Unpack")
    with Profiler() as p:
        for mult_file in os.listdir(path):
            if mult_file.lower().endswith(('.bin')):
                Unpack(mult_file)
    print("Закрыть")

def Unpack(mult_file):
    txt1 = open(path+"\\Unpack\\"+mult_file[:-4]+".txt","w", encoding="utf-8") # Указывает в какой кодировки сохранить текст
    f = open(path+"\\"+mult_file,"rb")
    type = f.read(4) # Тип
    if type != b'\xBA\xAF\x55\xCC': # Проверка
        print("ЭТО НЕ скрипт",type,mult_file)
        return(0) # Остановка скрипта
    offset_tab_text = struct.unpack("<I",f.read(4))[0] # Оффсет на таблицу оффсетов на текст в конце файла
    col_text = struct.unpack("<I",f.read(4))[0]   # Количество по 4 байта
    offset_tab_16byte = struct.unpack("<I",f.read(4))[0] # Оффсет начало таблица по 16 байт
    col_16 = struct.unpack("<I",f.read(4))[0]     # Количество строчек по 16 байт
    unclear_2 = struct.unpack("<I",f.read(4))[0]  # Непонятно всегда 0
    
    print(mult_file,"Оффсет на таблицу в конце",offset_tab_text,col_text)
    print("Оффсет начало таблица по 16 байт",offset_tab_16byte,"Количество строчек по 16 байт",col_16,unclear_2)
    
    f.seek(offset_tab_16byte)
    for i in range(col_16):
        unclear_1 = struct.unpack("<I",f.read(4))[0] # Непонятно
        unclear_2 = struct.unpack("<I",f.read(4))[0] # Оффсет на байт кода надо прибавить+24
        unclear_3 = struct.unpack("<I",f.read(4))[0] # Непонятно умножить на 4 получим раздницу межу unclear_2 и unclear_4
        unclear_4 = struct.unpack("<I",f.read(4))[0] # Оффсет конец команды ?
        #print(unclear_1,unclear_2,unclear_3,unclear_4,"разница",unclear_4-unclear_2,unclear_3*4 )

    offset_data = [] # Список оффсетов на текст
    f.seek(offset_tab_text)
    for i in range(col_text): 
        offset_text = struct.unpack("<I",f.read(4))[0]+offset_tab_text # Оффсеты на текст
        offset_data.append(offset_text)

    for i in offset_data: # Чтение текста
        f.seek(i)
        byte_string = b''
        while True:
            bytes = f.read(1)
            if bytes == b'\x00': # Если достигли конца строчки
                #print(byte_string)
                #print("Длина строчки текста",len(byte_string))
                #txt1.write(str(byte_string)+"\n") # Запись байт
                txt1.write(byte_string.decode("shift_jis_2004")+"\n") # shift_jis
                break
            byte_string += bytes
    f.close()
    txt1.close()
    print()

if __name__ == "__main__":
    main()
    input()